document.addEventListener('DOMContentLoaded', function () {

    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);

        const sections = document.querySelectorAll("section");

        sections.forEach(section => {
            gsap.from(section, {
                scrollTrigger: {
                    trigger: section,
                    start: "top 75%",
                    toggleActions: "play none none reverse",
                },
                opacity: 0,
                y: 50,
                duration: 1,
            });
        });
    }
});

// Animate teacher-group1 cards
gsap.utils.toArray(".teacher-group1 .tbox").forEach((box, i) => {
    gsap.from(box, {
        scrollTrigger: {
            trigger: box,
            start: "top 85%",
            toggleActions: "play none none none"
        },
        y: 50,
        opacity: 0,
        scale: 0.9,
        duration: 0.8,
        delay: i * 0.5,
        ease: "power3.out"
    });
});

// Animate teacher-group2 cards
gsap.utils.toArray(".teacher-group2 .tbox1").forEach((box, i) => {
    gsap.from(box, {
        scrollTrigger: {
            trigger: box,
            start: "top 85%",
            toggleActions: "play none none none"
        },
        y: 50,
        opacity: 0,
        scale: 0.9,
        duration: 0.8,
        delay: i * 0.5,
        ease: "power3.out"
    });
});



// Animate Section Titles
gsap.from(".heading1 h3", {
    opacity: 0,
    y: -50,
    duration: 1,
    ease: "power3.out",
});

// Home Section Animation
gsap.from(".home .image", {
    scrollTrigger: {
        trigger: ".home .image",
        start: "top 80%",
    },
    x: -100,
    opacity: 0,
    duration: 1.2,
    ease: "power3.out",
});
gsap.from(".home .content", {
    scrollTrigger: {
        trigger: ".home .content",
        start: "top 80%",
    },
    x: 100,
    opacity: 0,
    duration: 1.2,
    delay: 0.2,
    ease: "power3.out",
});

// Unique animation for all course boxes
const courseSelectors = [".C-box", ".P-box", ".J-box"];

courseSelectors.forEach(selector => {
    gsap.utils.toArray(selector).forEach((box, i) => {
        gsap.from(box, {
            scrollTrigger: {
                trigger: box,
                start: "top 85%",
                toggleActions: "play none none none",
            },
            opacity: 0,
            y: 50,
            scale: 0.8,
            rotateY: 15,
            duration: 1,
            delay: i * 0.15,
            ease: "back.out(1.7)",
        });
    });
});

function openForm() {
    document.getElementById("popupForm").style.display = "block";
  }
  function closeForm() {
    document.getElementById("popupForm").style.display = "none";
  }
  function submitForm(event) {
    event.preventDefault();
    document.getElementById("successMessage").style.display = "block";
    document.getElementById("enrollForm").style.display='none';
  }
